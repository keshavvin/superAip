import Herosection from "./Herosection"
import TeamSections from "./TeamSections"
function Home() {
  return (
    <>
       <Herosection/>
        <TeamSections/>
    </>
  )
}

export default Home